# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['qrdrop']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.3,<9.0.0', 'flask>=2.2.2,<3.0.0']

setup_kwargs = {
    'name': 'qrdrop',
    'version': '0.1.1',
    'description': 'CLI tool to transfer files between computer and mobile device over network.',
    'long_description': '',
    'author': 'Mark Solomonik',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
